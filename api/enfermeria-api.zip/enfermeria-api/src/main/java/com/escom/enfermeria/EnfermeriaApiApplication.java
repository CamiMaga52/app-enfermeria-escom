package com.escom.enfermeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnfermeriaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnfermeriaApiApplication.class, args);
	}

}
