package com.escom.enfermeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnfermeriaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
