export interface LoginRequest {
  correo: string;
  password: string;
}
