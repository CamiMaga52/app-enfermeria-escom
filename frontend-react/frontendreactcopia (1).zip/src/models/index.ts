export * from './Medicamento';
export * from './Material';
export * from './Paciente';
export * from './Receta';
export * from './LoginRequest';
